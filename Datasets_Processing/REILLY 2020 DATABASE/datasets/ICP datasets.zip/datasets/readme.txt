

These datasets were used to analyze the frequency of pollination limitation in US crops.  Each row represents a single transect at a site, spaced between 0 and 100m from the edge of a farm field or orchard. During peak flowering, timed pollinator observations were made in each transect.  Later, one or more crop production metrics were measured for the same transect.  See the publication for methods details.  The number of visits by each pollinator group are listed in separate columns.  Visits by wild_bees and all_bees for each transect (as used in the analysis) are simply sums across the relevant columns.  

